import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from '../pages/Home'
import Login from '../pages/Login'
import Register from '../pages/Register'
import QuizApp from '../pages/QuizApp'

function RouterConfig() {
  return (
    <Routes>
        <Route exact path='/' element={<Login />} />
        <Route exact path='/home' element={<Home />} />
        <Route exact path='/register' element={<Register />} />
        <Route exact path='/quizApp' element={<QuizApp />} />
    </Routes>
  )
}

export default RouterConfig